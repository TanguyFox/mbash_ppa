#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

#define MAXLI 2048
char cmd[MAXLI];
char path[MAXLI];
int pathidx;


void mbash();

int main(int argc, char **argv, char **env) {
    while (1) {
        printf("Commande:");
        fgets(cmd, MAXLI, stdin);
        mbash(cmd);
    }
    return 0;
}

void mbash() {
    char *dir = cmd + 3;

    /**
     * Méthode cd
     */
    if (strncmp(cmd, "cd", 2) == 0) {
        dir[strlen(dir) - 1] = '\0';
        if (chdir(dir) != 0) {
            printf("Repertoire inconnu%s\n", dir);
        } else {
            char *current_dir = getcwd(NULL, 0);
            printf("Execute: %s\n", cmd);
            printf("Repertoire courant: %s\n", current_dir);
            char *argv[] = {cmd, NULL};
            execve(cmd, argv, NULL);
        }

        /**
         * Méthode pwd
         */
    } else if (strncmp(cmd, "pwd", 3) == 0) {
        char *current_dir = getcwd(NULL, 0);
        printf("Repertoire courant: %s\n", current_dir);

        /**
         * Méthode ls
        */
    } else if (strncmp(cmd, "ls", 2) == 0) {
        struct dirent *lecture;
        char *current_dir = getcwd(NULL, 0);
        DIR *d = opendir(current_dir);
        if (d) {
            /**
             * Commande : ls
            */
            if (!cmd[3]) {
                while ((lecture = readdir(d))) {
                    if (lecture->d_name[0] != '.') {
                        printf("%s ", lecture->d_name);
                    }
                }
                printf("\n");
                /**
                 * Commande : ls -a
                */
            } else
                switch (cmd[3] + cmd[4]) {
                    case ('-' + 'a'):
                        while ((lecture = readdir(d))) {
                            printf("%s ", lecture->d_name);
                        }
                        printf("\n");
                        break;
                    default:
                        printf("Commande inconnue : %s\n", cmd);
                        break;
                }
            closedir(d);
        }
        /**
         * Methode exit
        */
    } else if (strncmp(cmd, "exit", 4) == 0) {
        exit(0);

        /**
         * Methode $
        */
    } else if (strncmp(cmd, "$", 1) == 0) {
        switch (cmd[1]) {

            /**
             * Commande : $$
             */
            case ('$') :
                printf("PID du terminal: %d\n", getpid());
                break;

                /**
                 * Commande : $?
                */
            case ('?') :
                printf("Code de retour du dernier processus: %d\n", 0);
                break;

                /**
                 * Commande : $#
                */
            case ('#') :
                printf("Nombre de commandes executees depuis le demarrage du terminal: %d\n", 0);
                break;
        }
    } else {
        printf("Commande inconnue : %s\n", cmd);
    }
}
